module.exports = {
    PORT: process.env.PORT,
    DIR: __dirname,
    secritKey: "dHJhbnNmZXJib3Q="
};
